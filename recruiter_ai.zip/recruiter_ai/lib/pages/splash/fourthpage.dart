import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/auth/authpage.dart';

import 'package:recruiter_ai/pages/splash/thirdpage.dart';

class ForthPage extends StatefulWidget {
  const ForthPage({super.key});

  @override
  State<ForthPage> createState() => _ForthPageState();
}

class _ForthPageState extends State<ForthPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 0),
                    child: NavigationComponent.skipButton(
                      onPressed: () {
                        NavigationComponent.navigateWithFadeSlide(
                          context: context,
                          page: AuthPage(),
                        );
                      },
                    ),
                  ),
                ],
              ),

              Center(child: Image.asset("assets/images/Robo Image.png")),

              Padding(
                padding: EdgeInsets.all(20),
                child: Align(
                  widthFactor: 10.0,
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    children: [
                      AppText.headingText(
                        text: "Boost Your Mind Power with Ai",
                      ),
                      SizedBox(height: 10),
                      AppText.bodyText(
                        text:
                            "Chat with the smartest AI Future Experience power of AI with us",
                      ),
                      SizedBox(height: 40),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ButtonComponent.buttonOnlyIcon(
                            icon: Icons.arrow_back,
                            context: context,
                            page: ThirdPage(),
                            width: 10,
                          ),
                          Container(width: 1, height: 50, color: Colors.grey),
                          ButtonComponent.buttonOnlyIcon(
                            icon: Icons.arrow_forward,
                            context: context,
                            page: AuthPage(),
                            width: 10,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
