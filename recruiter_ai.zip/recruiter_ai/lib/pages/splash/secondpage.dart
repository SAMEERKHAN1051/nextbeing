import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/auth/authpage.dart';
import 'package:recruiter_ai/pages/splash/thirdpage.dart';

class SecondPage extends StatefulWidget {
  const SecondPage({super.key});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Skip button aligned to top right
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: NavigationComponent.skipButton(
                        onPressed: () {
                          NavigationComponent.navigateWithFadeSlide(
                            context: context,
                            page: AuthPage(),
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // Robot image - takes flexible space
                  Expanded(
                    flex: 4,
                    child: Center(
                      child: Image.asset(
                        "assets/images/Robot Image.png",
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Text content
                  Expanded(
                    flex: 3,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        AppText.headingText(
                          text: "Unlock the Power Of  Future AI",
                        ),
                        const SizedBox(height: 10),
                        AppText.bodyText(
                          text:
                              "Chat with the smartest AI Future Experience power of AI with us",
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 10),

                  // Navigation buttons at bottom
                  Expanded(
                    flex: 2,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ButtonComponent.buttonOnlyIcon(
                              icon: Icons.arrow_back,
                              context: context,
                              page: null,
                              width: 10,
                              buttonType: false,
                            ),
                            Container(width: 1, height: 50, color: Colors.grey),
                            ButtonComponent.buttonOnlyIcon(
                              icon: Icons.arrow_forward,
                              context: context,
                              page: ThirdPage(),
                              width: 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
