import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_constant.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/splash/secondpage.dart';

class Firstpage extends StatefulWidget {
  const Firstpage({super.key});

  @override
  State<Firstpage> createState() => _FirstpageState();
}

class _FirstpageState extends State<Firstpage> {
  @override
  void initState() {
    super.initState();

    // Navigate to SecondPage after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 800),
          pageBuilder: (context, animation, secondaryAnimation) =>
              const SecondPage(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Slide from bottom and fade in
            final offsetAnimation =
                Tween<Offset>(
                  begin: const Offset(1.0, 0.0), // from bottom
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(parent: animation, curve: Curves.easeOut),
                );

            final fadeAnimation = CurvedAnimation(
              parent: animation,
              curve: Curves.easeIn,
            );

            return SlideTransition(
              position: offsetAnimation,
              child: FadeTransition(opacity: fadeAnimation, child: child),
            );
          },
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            Center(child: Image.asset("assets/images/Logo.png")),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Column(
                  children: [
                    AppText.headingText(text: "${AppConstant.appName}"),
                    AppText.bodyText(text: "version ${AppConstant.appVersion}"),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
