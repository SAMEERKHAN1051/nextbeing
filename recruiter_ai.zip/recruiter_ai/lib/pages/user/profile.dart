import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';
import 'package:recruiter_ai/service/authentication/authentication_service.dart';
import 'package:recruiter_ai/service/constant/constant_service.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  // Token (replace with actual token retrieval)
  final String token = "your_token_here";

  // Controllers
  final companyNameController = TextEditingController();
  final positionController = TextEditingController();
  final phoneController = TextEditingController();
  final locationController = TextEditingController();
  final addressController = TextEditingController();
  final websiteController = TextEditingController();
  final experienceController = TextEditingController();
  final aboutController = TextEditingController();
  final linkedinController = TextEditingController();

  bool isSubmitting = false;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    final profile = await AuthenticationService().getUserProfile(token);
    if (profile != null) {
      setState(() {
        companyNameController.text = profile.companyName;
        positionController.text = profile.position;
        phoneController.text = profile.phoneNumber;
        locationController.text = profile.location;
        addressController.text = profile.address ?? '';
        websiteController.text = profile.website ?? '';
        experienceController.text = profile.experience;
        aboutController.text = profile.about;
        linkedinController.text = profile.linkedin ?? '';
      });
    }
  }

  Future<void> submit() async {
    setState(() => isSubmitting = true);

    final body = {
      "companyName": companyNameController.text,
      "position": positionController.text,
      "phoneNumber": phoneController.text,
      "location": locationController.text,
      "address": addressController.text,
      "website": websiteController.text,
      "experience": experienceController.text,
      "about": aboutController.text,
      "linkedin": linkedinController.text,
    };

    final res = await ConstantService().postRequest(
      "profile-update",
      body,
      token: token,
    );

    setState(() => isSubmitting = false);

    if (res.statusCode == 200) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("✅ Profile updated")));
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("❌ Update failed")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            InputComponents.inputField(
              controller: companyNameController,
              hintText: "Company Name",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: positionController,
              hintText: "Position",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: phoneController,
              hintText: "Phone Number",
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: locationController,
              hintText: "Location",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: addressController,
              hintText: "Address",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: websiteController,
              hintText: "Website",
              keyboardType: TextInputType.url,
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: experienceController,
              hintText: "Experience",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: aboutController,
              hintText: "About",
            ),
            const SizedBox(height: 16),
            InputComponents.inputField(
              controller: linkedinController,
              hintText: "LinkedIn",
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: isSubmitting ? null : submit,
              child: isSubmitting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Save Changes"),
            ),
          ],
        ),
      ),
    );
  }
}
