import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';
import 'package:recruiter_ai/model/fieldmodel.dart';
import 'package:recruiter_ai/service/constant/constant_service.dart';

class Field extends StatefulWidget {
  const Field({super.key});

  @override
  State<Field> createState() => _FieldState();
}

class _FieldState extends State<Field> {
  late Future<List<FieldModel>> futureOptions;
  FieldModel? selectedField;
  bool isSubmitting = false;

  // TODO: Replace this with actual token fetching logic (e.g., from login, SharedPreferences, etc.)
  final String userToken = "your_auth_token_here";

  @override
  void initState() {
    super.initState();
    futureOptions = ConstantService().getField(); // No token required for GET
  }

  Future<void> submit() async {
    if (selectedField == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("⚠️ Please select a field")));
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    final success = await ConstantService().sendSelectedFieldName(
      selectedField!.name,
      userToken,
    );

    setState(() {
      isSubmitting = false;
    });

    if (success) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("✅ Sent: ${selectedField!.name}")));
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("❌ Failed to send")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Select Field")),
      body: FutureBuilder<List<FieldModel>>(
        future: futureOptions,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          final fields = snapshot.data ?? [];

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                InputComponents.dropdownField<FieldModel>(
                  items: fields,
                  selectedValue: selectedField,
                  getLabel: (item) => item.name,
                  labelText: "Select Field",
                  onChanged: (value) {
                    setState(() {
                      selectedField = value;
                    });
                  },
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: isSubmitting ? null : submit,
                  child: isSubmitting
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Submit"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
