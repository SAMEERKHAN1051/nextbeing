import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';
// Update path as needed

class JobPostingForm extends StatefulWidget {
  @override
  _JobPostingFormState createState() => _JobPostingFormState();
}

class _JobPostingFormState extends State<JobPostingForm> {
  final TextEditingController _jobTitleController = TextEditingController();
  final TextEditingController _companyController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _salaryController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  void _submitForm() {
    if (_jobTitleController.text.isEmpty ||
        _companyController.text.isEmpty ||
        _locationController.text.isEmpty ||
        _salaryController.text.isEmpty ||
        _descriptionController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Please fill out all fields')));
      return;
    }

    // You can handle the form submission here
    // For now, just show a dialog:
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Job Submitted"),
        content: Text("Your job has been posted successfully!"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _jobTitleController.dispose();
    _companyController.dispose();
    _locationController.dispose();
    _salaryController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Post a Job"),
        backgroundColor: ColorConstant.primaryTextColor,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            InputComponents.inputField(
              controller: _jobTitleController,
              hintText: "Job Title",
              prefixIcon: Icons.work_outline,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _companyController,
              hintText: "Company Name",
              prefixIcon: Icons.business_outlined,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _locationController,
              hintText: "Location",
              prefixIcon: Icons.location_on_outlined,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _salaryController,
              hintText: "Salary",
              keyboardType: TextInputType.number,
              prefixIcon: Icons.attach_money_outlined,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _descriptionController,
              hintText: "Job Description",
              prefixIcon: Icons.description_outlined,
              // If you want multiline:
              keyboardType: TextInputType.multiline,
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorConstant.primaryTextColor,
                ),
                onPressed: _submitForm,
                child: Text(
                  "Submit",
                  style: AppTextStyle.buttonTextStyle.copyWith(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
