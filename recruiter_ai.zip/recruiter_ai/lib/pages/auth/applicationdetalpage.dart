import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';

class ApplicantDetailPage extends StatelessWidget {
  final String name;
  final String email;
  final String phone;
  final String bio;
  final List<String> skills;
  final String applyDate;

  const ApplicantDetailPage({
    Key? key,
    required this.name,
    required this.email,
    required this.phone,
    required this.bio,
    required this.skills,
    required this.applyDate,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Applicant Details"),
        backgroundColor: ColorConstant.primaryTextColor,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLabel("Name"),
            _buildValue(name),
            _buildLabel("Email"),
            _buildValue(email),
            _buildLabel("Phone"),
            _buildValue(phone),
            _buildLabel("Resume Summary"),
            _buildValue(bio),
            _buildLabel("Skills"),
            Wrap(
              spacing: 8,
              children: skills
                  .map(
                    (skill) => Chip(
                      label: Text(skill),
                      backgroundColor: ColorConstant.buttonSecondaryColor,
                    ),
                  )
                  .toList(),
            ),
            _buildLabel("Applied On"),
            _buildValue(applyDate),
            SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Application Accepted")),
                      );
                    },
                    child: Text("Accept"),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Application Rejected")),
                      );
                    },
                    child: Text("Reject"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 4),
      child: Text(
        label,
        style: AppTextStyle.bodyTextStyle.copyWith(
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildValue(String value) {
    return Text(
      value,
      style: AppTextStyle.bodyTextStyle.copyWith(fontSize: 15),
    );
  }
}
