import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/components/lists/list_components.dart';
import 'package:recruiter_ai/constant/app_constant.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/auth/applicationdetalpage.dart';
import 'package:recruiter_ai/pages/auth/jobdetailpageforapplicant.dart';
import 'package:recruiter_ai/pages/auth/loginpage.dart';
import 'package:recruiter_ai/pages/auth/signuppage.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Logo
              Column(
                children: [
                  Center(child: Image.asset(AppConstant.mainLogoPath)),
                  const SizedBox(height: 20),

                  // Welcome Text
                  AppText.headingText(
                    text: "Welcome To ${AppConstant.appName}",
                  ),

                  const SizedBox(height: 20),

                  // Optional Job Card Preview
                  ListComponents().jobCard(
                    jobTitle: "UI/UX Designer",
                    companyName: "Creative Studio",
                    location: "New York, NY",
                    jobType: "Full-time",
                    icon: Icons.design_services,
                    onTap: () {
                      NavigationComponent.navigateWithFadeSlide(
                        context: context,
                        page: JobDetailPageForApplicant(
                          jobTitle: "Flutter Developer",
                          companyName: "TechCorp Inc.",
                          location: "Remote / San Francisco",
                          salary: "\$90,000 - \$120,000",
                          description:
                              "We are looking for a skilled Flutter developer to join our team and help build amazing mobile apps...",
                        ),
                      );
                    },
                  ),
                ],
              ),

              // Auth Buttons
              Column(
                children: [
                  ButtonComponent.primaryButton(
                    text: "Log In",
                    onPressed: () {
                      NavigationComponent.navigateWithFadeSlide(
                        context: context,
                        page: LoginPage(),
                      );
                    },
                    width: 400,
                  ),
                  const SizedBox(height: 20),
                  ButtonComponent.secondaryButton(
                    text: "Sign Up",
                    onPressed: () {
                      NavigationComponent.navigateWithFadeSlide(
                        context: context,
                        page: SignUpPage(),
                      );
                    },
                    width: 400,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
