import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/constant/app_constant.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/auth/loginpage.dart';
import 'package:recruiter_ai/pages/auth/signuppage.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(child: Image.asset(AppConstant.mainLogoPath)),
              Padding(
                padding: EdgeInsets.all(20),
                child: Align(
                  widthFactor: 10.0,
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    children: [
                      AppText.headingText(
                        text: "Welcome To ${AppConstant.appName}",
                      ),
                      SizedBox(height: 40),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ButtonComponent.primaryButton(
                            text: "Log In",
                            onPressed: () {
                              NavigationComponent.navigateWithFadeSlide(
                                context: context,
                                page: LoginPage(),
                              );
                            },
                            width: 400,
                          ),
                          SizedBox(height: 20),
                          ButtonComponent.secondaryButton(
                            text: "Sign Up",
                            onPressed: () {
                              NavigationComponent.navigateWithFadeSlide(
                                context: context,
                                page: SignUpPage(),
                              );
                            },
                            width: 400,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
