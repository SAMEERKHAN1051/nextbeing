import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';

class JobDetailPageForApplicant extends StatelessWidget {
  final String jobTitle;
  final String companyName;
  final String location;
  final String salary;
  final String description;

  const JobDetailPageForApplicant({
    Key? key,
    required this.jobTitle,
    required this.companyName,
    required this.location,
    required this.salary,
    required this.description,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Job Details"),
        backgroundColor: ColorConstant.primaryTextColor,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection("Job Title", jobTitle),
            _buildSection("Company", companyName),
            _buildSection("Location", location),
            _buildSection("Salary", salary),
            _buildSection("Job Description", description),
            SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ColorConstant.primaryTextColor,
                    ),
                    onPressed: () {
                      // TODO: Implement Apply functionality
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Application Submitted")),
                      );
                    },
                    child: Text(
                      "Apply Now",
                      style: AppTextStyle.buttonTextStyle.copyWith(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: ColorConstant.primaryTextColor),
                    ),
                    onPressed: () {
                      // TODO: Save job functionality
                      ScaffoldMessenger.of(
                        context,
                      ).showSnackBar(SnackBar(content: Text("Job Saved")));
                    },
                    child: Text(
                      "Save Job",
                      style: AppTextStyle.buttonTextStyle.copyWith(
                        color: ColorConstant.primaryTextColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppTextStyle.bodyTextStyle.copyWith(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          SizedBox(height: 6),
          Text(value, style: AppTextStyle.bodyTextStyle.copyWith(fontSize: 15)),
        ],
      ),
    );
  }
}
