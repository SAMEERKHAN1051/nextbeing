import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';
import 'package:recruiter_ai/constant/color_constant.dart';
import 'package:recruiter_ai/constant/app_text.dart';

class ApplicationFormPage extends StatefulWidget {
  const ApplicationFormPage({super.key});

  @override
  State<ApplicationFormPage> createState() => _ApplicationFormPageState();
}

class _ApplicationFormPageState extends State<ApplicationFormPage> {
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _coverLetterController = TextEditingController();

  void _submitApplication() {
    if (_fullNameController.text.isEmpty ||
        _emailController.text.isEmpty ||
        _phoneController.text.isEmpty ||
        _coverLetterController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Please complete all fields')));
      return;
    }

    // TODO: Submit the application to the backend or save locally

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Application Submitted"),
        content: Text("Thank you for applying. We will contact you soon."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _coverLetterController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Job Application"),
        backgroundColor: ColorConstant.primaryTextColor,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            InputComponents.inputField(
              controller: _fullNameController,
              hintText: "Full Name",
              prefixIcon: Icons.person_outline,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _emailController,
              hintText: "Email",
              keyboardType: TextInputType.emailAddress,
              prefixIcon: Icons.email_outlined,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _phoneController,
              hintText: "Phone Number",
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              prefixIcon: Icons.phone_outlined,
            ),
            SizedBox(height: 16),
            InputComponents.inputField(
              controller: _coverLetterController,
              hintText: "Cover Letter",
              keyboardType: TextInputType.multiline,
              prefixIcon: Icons.message_outlined,
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorConstant.primaryTextColor,
                ),
                onPressed: _submitApplication,
                child: Text(
                  "Submit Application",
                  style: AppTextStyle.buttonTextStyle.copyWith(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
