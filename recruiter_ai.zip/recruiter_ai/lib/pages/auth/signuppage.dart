import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';

import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/pages/auth/authpage.dart';
import 'package:recruiter_ai/pages/auth/loginpage.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 0,
                          vertical: 0,
                        ),
                        child: NavigationComponent.skipButton(
                          loginPage: true,
                          onPressed: () {
                            NavigationComponent.navigateWithFadeSlide(
                              context: context,
                              page: AuthPage(),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 50),

                  Padding(
                    padding: EdgeInsets.all(20),
                    child: Align(
                      widthFactor: 10.0,
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        children: [
                          AppText.headingText(
                            text: "Create your Account",
                            allign: false,
                          ),
                          SizedBox(height: 50),
                          Column(
                            children: [
                              InputComponents.inputField(
                                prefixIcon: Icons.person,
                                hintText: "Enter Your Name",
                              ),
                              SizedBox(height: 10),
                              InputComponents.inputField(
                                prefixIcon: Icons.email,
                                hintText: "Enter Your Email",
                              ),
                              SizedBox(height: 10),
                              InputComponents.inputField(
                                obscureText: true,
                                keyboardType: TextInputType.visiblePassword,
                                prefixIcon: Icons.password,
                                hintText: "Password",
                                suffixIcon: Icons.remove_red_eye,
                              ),
                              SizedBox(height: 20),
                              ButtonComponent.primaryButton(
                                text: "Register",
                                onPressed: () {},
                              ),
                              SizedBox(height: 20),
                              Align(
                                alignment: Alignment.center,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    AppText.bodyText(
                                      text: "Already Have An Account? ",
                                    ),
                                    AppText.navigationBodyText(
                                      bold: true,
                                      onPress: () {
                                        NavigationComponent.navigateWithFadeSlide(
                                          context: context,
                                          page: LoginPage(),
                                        );
                                      },
                                      text: "Sign In",
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Divider(),
            SizedBox(height: 20),
            Align(
              alignment: Alignment.center,
              child: AppText.bodyText(text: "Continue With Accounts"),
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ButtonComponent.customButton(
                    text: "Google",
                    onPressed: () {},
                    width: 165,
                    red: true,
                  ),
                  SizedBox(height: 20, width: 20),

                  ButtonComponent.customButton(
                    text: "Facebook",
                    onPressed: () {},
                    width: 165,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
