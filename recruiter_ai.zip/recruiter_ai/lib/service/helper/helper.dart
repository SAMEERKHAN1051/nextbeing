import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:recruiter_ai/constant/app_constant.dart';

class Helper {
  Future<http.Response> getRequest(
    String endpoint, {
    Map<String, String>? headers,
  }) async {
    final uri = Uri.parse("${AppConstant.ApiUrl}$endpoint");
    final response = await http.get(
      uri,
      headers: headers ?? {"Content-Type": "application/json"},
    );

    return response;
  }

  Future<http.Response> getRequestByToken(
    String endpoint, {
    String? token,
  }) async {
    final response = await http.get(
      Uri.parse("${AppConstant.ApiUrl}$endpoint"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
    );
    return response;
  }

  Future<http.Response> postRequest(
    String endpoint,
    Map<String, dynamic> data, {
    String? token,
  }) async {
    final response = await http.post(
      Uri.parse("${AppConstant.ApiUrl}$endpoint"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
      body: jsonEncode(data),
    );
    return response;
  }
}
