import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:recruiter_ai/constant/app_constant.dart';

class AuthenticationService {
  Future<void> sendIdTokenToBackend(String idToken, String provider) async {
    final response = await http.post(
      Uri.parse("${AppConstant.ApiUrl}social-login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "provider": provider, // "google" or "facebook"
        "firebase_id_token": idToken,
      }),
    );

    if (response.statusCode == 200) {
      print("✅ Login successful: ${response.body}");
    } else {
      print("❌ Login failed: ${response.statusCode}, ${response.body}");
    }
  }
}
