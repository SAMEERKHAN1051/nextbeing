import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:recruiter_ai/constant/app_constant.dart';
import 'package:recruiter_ai/model/user_profile_model.dart';
import 'package:recruiter_ai/service/helper/helper.dart';

class AuthenticationService extends Helper {
  Future<void> sendIdTokenToBackend(String idToken, String provider) async {
    final response = await http.post(
      Uri.parse("${AppConstant.ApiUrl}social-login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "provider": provider, // "google" or "facebook"
        "firebase_id_token": idToken,
      }),
    );

    if (response.statusCode == 200) {
      print("✅ Login successful: ${response.body}");
    } else {
      print("❌ Login failed: ${response.statusCode}, ${response.body}");
    }
  }

  Future<UserProfileModel?> getUserProfile(String token) async {
    final response = await getRequestByToken("user", token: token);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body)['data'];
      return UserProfileModel.fromJson(data);
    } else {
      print("❌ Error: ${response.body}");
      return null;
    }
  }
}
