import 'dart:convert';
import 'package:recruiter_ai/model/fieldmodel.dart';
import 'package:recruiter_ai/service/helper/helper.dart';

class ConstantService extends Helper {
  Future<List<FieldModel>> getField() async {
    final response = await getRequest("field");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((json) => FieldModel.fromJson(json)).toList();
    }

    return [];
  }

  Future<bool> sendSelectedFieldName(String fieldName, String token) async {
    final response = await postRequest(
      "submit-field",
      {"fieldName": fieldName},
      token: token, 
    );

    return response.statusCode == 200;
  }
}
