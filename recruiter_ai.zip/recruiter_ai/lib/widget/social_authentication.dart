import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:recruiter_ai/service/authentication/authentication_service.dart';

class SocialAuthentication extends StatefulWidget {
  const SocialAuthentication({super.key});

  @override
  State<SocialAuthentication> createState() => _SocialAuthenticationState();
}

class _SocialAuthenticationState extends State<SocialAuthentication> {
  Future<String?> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return null;

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential = await FirebaseAuth.instance.signInWithCredential(
      credential,
    );
    return await userCredential.user?.getIdToken();
  }

  Future<String?> signInWithFacebook() async {
    final result = await FacebookAuth.instance.login();
    if (result.status != LoginStatus.success) return null;

    final credential = FacebookAuthProvider.credential(
      result.accessToken!.token,
    );
    final userCredential = await FirebaseAuth.instance.signInWithCredential(
      credential,
    );
    return await userCredential.user?.getIdToken();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              ButtonComponent.customButton(
                text: "Google",
                onPressed: () async {
                  final idToken = await signInWithGoogle();
                  if (idToken != null) {
                    await AuthenticationService().sendIdTokenToBackend(
                      idToken,
                      "google",
                    );
                  } else {
                    print("Google sign-in cancelled or failed");
                  }
                },
                width: 165,
                red: true,
              ),
              const SizedBox(width: 20),
              ButtonComponent.customButton(
                text: "Facebook",
                onPressed: () async {
                  final idToken = await signInWithFacebook();
                  if (idToken != null) {
                    await AuthenticationService().sendIdTokenToBackend(
                      idToken,
                      "facebook",
                    );
                  } else {
                    print("Facebook sign-in cancelled or failed");
                  }
                },
                width: 165,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
