class FieldModel {
  final String id;
  final String name;
  final DateTime createdAt;

  FieldModel({required this.id, required this.name, required this.createdAt});

  factory FieldModel.fromJson(Map<String, dynamic> json) {
    return FieldModel(
      id: json['_id'],
      name: json['name'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }
}
