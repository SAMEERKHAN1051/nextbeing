class UserProfileModel {
  final String companyName;
  final String position;
  final String phoneNumber;
  final String location;
  final String? address;
  final String? website;
  final String experience;
  final String about;
  final List<String> language;
  final String? companyDescription;
  final String? cv;
  final String? linkedin;

  UserProfileModel({
    required this.companyName,
    required this.position,
    required this.phoneNumber,
    required this.location,
    this.address,
    this.website,
    required this.experience,
    required this.about,
    required this.language,
    this.companyDescription,
    this.cv,
    this.linkedin,
  });

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    return UserProfileModel(
      companyName: json['companyName'],
      position: json['position'],
      phoneNumber: json['phoneNumber'],
      location: json['location'],
      address: json['address'],
      website: json['website'],
      experience: json['experience'],
      about: json['about'],
      language: List<String>.from(json['language'] ?? []),
      companyDescription: json['companyDescription'],
      cv: json['cv'],
      linkedin: json['linkedin'],
    );
  }
}
