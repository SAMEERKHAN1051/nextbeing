import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/button_component.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/components/inputs/input_components.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';
import 'package:recruiter_ai/pages/splash/firstpage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        fontFamily: 'Poppins', // Set your global font
        primaryColor: ColorConstant.primaryColor,
        scaffoldBackgroundColor: ColorConstant.primaryColor,
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 16.0),
          bodyMedium: TextStyle(fontSize: 14.0),
        ),
      ),
      home: const Firstpage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // AppText.headingText('Unlock the Power Of Future AI!', true),
            // AppText.bodyText('This is a paragraph.', false),
            AppText.primaryIcon(Icons.add_ic_call_outlined, 15),
            ButtonComponent.primaryButton(
              text: "hello world",
              onPressed: () {},
              width: 154,
            ),
            NavigationComponent.backButton(onPressed: () {}),
            InputComponents.inputField(prefixIcon: Icons.email),
            InputComponents.inputField(prefixIcon: Icons.email),
          ],
        ),
      ),
    );
  }
}
