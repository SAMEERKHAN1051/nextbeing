import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_text.dart';

class ListComponents {
  static ListTile listTilePref({
    IconData icon = Icons.arrow_back,
    required String text,
    required String secondarytext,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: AppText.primaryIcon(icon, 34),
      title: AppText.semiHeadingText(text: text, allign: false),
      subtitle: AppText.smallText(text: secondarytext, allign: false),
      onTap: onTap,
    );
  }

  static ListTile listTileSetting({
    IconData leadIcon = Icons.arrow_back,
    IconData trailIcon = Icons.arrow_back,
    required String text,
    required String secondarytext,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: AppText.primaryIcon(leadIcon, 34),
      title: AppText.semiHeadingText(text: text, allign: false),
      trailing: AppText.primaryIcon(trailIcon, 34),
      onTap: onTap,
    );
  }

  Widget jobCard({
    required String jobTitle,
    required String companyName,
    required String location,
    required String jobType,
    IconData icon = Icons.work_outline,
    VoidCallback? onTap,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              // Icon or logo
              CircleAvatar(
                backgroundColor: Colors.grey.shade200,
                radius: 28,
                child: Icon(icon, size: 28, color: Colors.blueGrey),
              ),
              const SizedBox(width: 16),

              // Job details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      jobTitle,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      companyName,
                      style: const TextStyle(color: Colors.black54),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$location • $jobType',
                      style: const TextStyle(fontSize: 13, color: Colors.grey),
                    ),
                  ],
                ),
              ),

              // Optional trailing icon
              IconButton(
                icon: const Icon(Icons.bookmark_border),
                onPressed: () {
                  // Optional: handle bookmark tap
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
