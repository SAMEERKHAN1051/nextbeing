import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_text.dart';

class ListComponents {
  static ListTile listTilePref({
    IconData icon = Icons.arrow_back,
    required String text,
    required String secondarytext,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: AppText.primaryIcon(icon, 34),
      title: AppText.semiHeadingText(text: text, allign: false),
      subtitle: AppText.smallText(text: secondarytext, allign: false),
      onTap: onTap,
    );
  }

  static ListTile listTileSetting({
    IconData leadIcon = Icons.arrow_back,
    IconData trailIcon = Icons.arrow_back,
    required String text,
    required String secondarytext,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: AppText.primaryIcon(leadIcon, 34),
      title: AppText.semiHeadingText(text: text, allign: false),
      trailing: AppText.primaryIcon(trailIcon, 34),
      onTap: onTap,
    );
  }
}
