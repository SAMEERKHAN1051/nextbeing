import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';

class InputComponents {
  static Widget inputField({
    TextEditingController? controller,
    String hintText = '',
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
    bool obscureText = false,
    IconData? prefixIcon,
    IconData? suffixIcon,
    VoidCallback? onSuffixTap,
    double height = 65,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      cursorColor: ColorConstant.primaryTextColor,
      style: AppTextStyle.bodyTextStyle,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: AppTextStyle.bodyTextStyle,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.84),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.84),
          borderSide: BorderSide(
            color: ColorConstant.primaryTextColor,
            width: 1.5,
          ),
        ),
        prefixIcon: prefixIcon != null
            ? Padding(
                padding: EdgeInsets.all(16.0),
                child: Icon(prefixIcon, size: 24), // icon is 48px widget.
              )
            : null,
        prefixIconColor: ColorConstant.primaryTextColor,
        suffixIconColor: ColorConstant.primaryTextColor,
        suffixIcon: suffixIcon != null
            ? GestureDetector(
                onTap: onSuffixTap,
                child: Icon(suffixIcon, size: 24),
              )
            : null,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 24,
        ),
        filled: true,
        fillColor: ColorConstant.buttonSecondaryColor,
      ),
    );
  }
}
