import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';
import 'package:recruiter_ai/pages/splash/firstpage.dart';

class NavigationComponent {
  static FloatingActionButton backButton({required VoidCallback onPressed}) {
    return FloatingActionButton(
      onPressed: onPressed,
      backgroundColor: ColorConstant.buttonPrimaryColor,
      hoverColor: ColorConstant.buttonSecondaryColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: AppText.primaryIcon(Icons.chevron_left_outlined, 38),
    );
  }

  static FloatingActionButton skipButton({
    required VoidCallback onPressed,
    String text = "Skip",
    Icon icon = const Icon(Icons.arrow_back_ios_new),
    bool loginPage = false,
  }) {
    return FloatingActionButton(
      onPressed: onPressed,
      backgroundColor: loginPage
          ? ColorConstant.buttonSecondaryColor
          : ColorConstant.primaryColor,
      hoverColor: ColorConstant.buttonSecondaryColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: loginPage
          ? AppText.primaryIcon(Icons.arrow_back_ios_new, 24)
          : AppText.buttonText(text: "Skip", primary: false),
    );
  }

  static void navigateWithFadeSlide({
    required BuildContext context,
    Widget? page,
  }) {
    if (page == null) return;
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 700),
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final offset = Tween<Offset>(
            begin: const Offset(1.0, 0.0),
            end: Offset.zero,
          ).animate(animation);

          final opacity = Tween<double>(
            begin: 0.0,
            end: 1.0,
          ).animate(animation);

          return SlideTransition(
            position: offset,
            child: FadeTransition(opacity: opacity, child: child),
          );
        },
      ),
    );
  }
}
