import 'package:flutter/material.dart';
import 'package:recruiter_ai/components/buttons/navigation_component.dart';
import 'package:recruiter_ai/constant/app_text.dart';
import 'package:recruiter_ai/constant/color_constant.dart';
import 'package:recruiter_ai/pages/splash/firstpage.dart';

class ButtonComponent {
  static ElevatedButton primaryButton({
    required String text,
    required VoidCallback onPressed,
    double width = double.infinity,
    double height = 66,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        overlayColor: ColorConstant.buttonSecondaryColor,
        backgroundColor: ColorConstant.buttonPrimaryColor,
        minimumSize: Size(width, height),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: AppText.buttonText(text: text),
    );
  }

  static ElevatedButton customButton({
    required String text,
    required VoidCallback onPressed,
    double width = double.infinity,
    double height = 66,
    bool red = false,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        overlayColor: ColorConstant.buttonSecondaryColor,
        backgroundColor: red ? Color(0xFF442320) : Color(0xFF202B3F),
        minimumSize: Size(width, height),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: AppText.buttonText(text: text),
    );
  }

  static ElevatedButton secondaryButton({
    required String text,
    required VoidCallback onPressed,
    double width = double.infinity,
    double height = 66,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: ColorConstant.buttonSecondaryColor,
        minimumSize: Size(width, height),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: AppText.buttonText(text: text, primary: false),
    );
  }

  static ElevatedButton buttonIcon({
    required String text,
    required VoidCallback onPressed,
    IconData icon = Icons.arrow_back,
    double width = double.infinity,
    double height = 66,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        overlayColor: ColorConstant.buttonSecondaryColor,
        backgroundColor: ColorConstant.buttonPrimaryColor,
        minimumSize: Size(width, height),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(width: 8),
          AppText.buttonText(text: text),
          AppText.primaryIcon(icon, 24),
        ],
      ),
    );
  }

  static ElevatedButton buttonOnlyIcon({
    required BuildContext context,
    Widget? page,
    IconData icon = Icons.arrow_back,
    double width = double.infinity,
    double height = 66,
    bool buttonType = true,
  }) {
    return ElevatedButton(
      onPressed: () {
        NavigationComponent.navigateWithFadeSlide(context: context, page: page);
      },
      style: ElevatedButton.styleFrom(
        overlayColor: ColorConstant.buttonSecondaryColor,
        backgroundColor: ColorConstant.buttonPrimaryColor,
        minimumSize: Size(width, height),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(width: 8),
          buttonType
              ? AppText.primaryIcon(icon, 24)
              : AppText.secondaryIcon(icon, 24),
        ],
      ),
    );
  }
}
