import 'package:flutter/widgets.dart';
import 'package:recruiter_ai/constant/app_text.dart';

class TypographyComponent {
  static Widget centerHeading(String text) {
    return Column(children: [AppText.headingText(text: text)]);
  }

  static Widget startHeading(String text) {
    return Column(children: [AppText.headingText(text: text, allign: false)]);
  }

  static Widget topHeading(String text) {
    return Column(children: [AppText.headingText(text: text, allign: false)]);
  }




}
