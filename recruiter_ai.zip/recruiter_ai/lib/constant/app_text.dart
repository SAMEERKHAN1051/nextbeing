import 'package:flutter/material.dart';
import 'package:recruiter_ai/constant/color_constant.dart';

class AppTextStyle {
  static const String fontFamily = 'Poppins';

  static const TextStyle headingTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 33.9,
    fontWeight: FontWeight.bold,
    color: ColorConstant.primaryTextColor,
  );
  static const TextStyle semiHeadingTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 19,
    fontWeight: FontWeight.bold,
    color: ColorConstant.primaryTextColor,
  );

  static const TextStyle bodyTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16.3,
    fontWeight: FontWeight.w300,
    color: ColorConstant.secondaryTextColor,
  );
  static const TextStyle navigationBodyTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16.3,
    decoration: TextDecoration.underline,
    decorationColor: ColorConstant.secondaryTextColor,
    fontWeight: FontWeight.w300,
    color: ColorConstant.secondaryTextColor,
  );

  static const TextStyle smallTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 12,
    fontWeight: FontWeight.w300,
    color: ColorConstant.primaryTextColor,
  );
  static const TextStyle buttonTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16,
    fontWeight: FontWeight.w700,
    color: ColorConstant.primaryTextColor,
  );
  static const TextStyle buttonSecondaryTextStyle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16,
    fontWeight: FontWeight.w700,
    color: ColorConstant.secondaryTextColor,
  );
}

class AppText implements AppTextStyle {
  static Text headingText({String text = "", bool allign = true}) {
    return Text(
      text,
      textAlign: allign ? TextAlign.center : TextAlign.start,
      style: AppTextStyle.headingTextStyle,
    );
  }

  static Text semiHeadingText({String text = "", bool allign = true}) {
    return Text(
      text,
      textAlign: allign ? TextAlign.center : TextAlign.start,
      style: AppTextStyle.semiHeadingTextStyle,
    );
  }

  static Text buttonText({String text = "", bool primary = false}) {
    final String capitalizedText = text.isNotEmpty
        ? text[0].toUpperCase() + text.substring(1)
        : '';
    return Text(
      capitalizedText,
      style: primary
          ? AppTextStyle.buttonTextStyle
          : AppTextStyle.buttonSecondaryTextStyle,
    );
  }

  static Text bodyText({String text = "", bool allign = true}) {
    return Text(
      text,
      textAlign: allign ? TextAlign.center : TextAlign.start,
      style: AppTextStyle.bodyTextStyle,
    );
  }

  static GestureDetector navigationBodyText({
    String text = "",
    bool allign = true,
    required VoidCallback onPress,
    bool bold = false,
  }) {
    return GestureDetector(
      onTap: onPress,
      child: Text(
        text,
        textAlign: allign ? TextAlign.center : TextAlign.start,
        style: bold
            ? AppTextStyle.buttonTextStyle
            : AppTextStyle.navigationBodyTextStyle,
      ),
    );
  }

  static Text smallText({String text = "", bool allign = true}) {
    return Text(
      text,
      textAlign: allign ? TextAlign.center : TextAlign.start,
      style: AppTextStyle.smallTextStyle,
    );
  }

  static Icon primaryIcon(IconData iconData, double size) {
    return Icon(iconData, size: size, color: ColorConstant.primaryTextColor);
  }

  static Icon secondaryIcon(IconData iconData, double size) {
    return Icon(iconData, size: size, color: ColorConstant.secondaryTextColor);
  }
}
