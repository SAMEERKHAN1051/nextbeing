import 'package:flutter/material.dart';
class ColorConstant {
  static const primaryColor = Color(0xFF141718);
  static const secondaryColor = Color(0xFF232627);
  static const primaryTextColor = Color(0xFFFFFFFF);
  static const secondaryTextColor = Color(0xFFACADB9);
  static const buttonPrimaryColor = Color(0xFF1B1E20);
  static const buttonSecondaryColor = Color(0xFF232627);
}
