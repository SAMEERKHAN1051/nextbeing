class AppConstant {
  static String appName = "NextBeing.AI";
  static String appVersion = "1.0";
  static String mainLogoPath = "assets/images/Logo.png";
  static String ApiUrl = "https://nextbeingai-backend.vercel.app/api/";
}
